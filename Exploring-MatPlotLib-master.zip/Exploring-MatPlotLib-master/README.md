# Learning-MatPlotLib
Matplotlib is a plotting library for the Python programming language and its numerical mathematics extension NumPy. It provides an object-oriented API for embedding plots into applications using general-purpose GUI toolkits like Tkinter, wxPython, Qt, or GTK+.

Some of the major Pros of Matplotlib are:

1) Generally easy to get started for simple plots

2) Support for custom labels and texts

3) Great control of every element in a figure

4) High-quality output in many formats

5) Very customizable in general
